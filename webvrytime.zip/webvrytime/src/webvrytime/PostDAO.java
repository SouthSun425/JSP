package webvrytime;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class PostDAO {
	private Connection con;
	private PreparedStatement pstmt;
	private DataSource dataFactory;

	public PostDAO() {
		try {
			Context ctx = new InitialContext();
			Context envContext = (Context) ctx.lookup("java:/comp/env");
			dataFactory = (DataSource) envContext.lookup("jdbc/oracle");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public PostBean getPost(String title) {
		PostBean post = null;

	       try {
	           con = dataFactory.getConnection();
	           String query = "SELECT title, id, content FROM board WHERE title = ?";
	           pstmt = con.prepareStatement(query);
	           pstmt.setString(1, title);
	           ResultSet rs = pstmt.executeQuery();
	           if (rs.next()) {
	               
	               String title1 = rs.getString("title");
	               String id = rs.getString("id");
	               String content = rs.getString("content");
	               

	               post = new PostBean();
	               post.setTitle(title);
	               post.setId(id);
	               post.setContent(content);
	               
	           }
	       } catch (Exception e) {
	           e.printStackTrace();
	       } 
	       return post;
	   }


	
	public List<PostBean> listPosts() {
		List<PostBean> list = new ArrayList<PostBean>();
		try {
			// connDB();
			con = dataFactory.getConnection();
			String query = "select title, id, content from board";
			System.out.println("prepareStatememt: " + query);
			pstmt = con.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String title = rs.getString("title");
				String id = rs.getString("id");
				String content = rs.getString("content");

				
				PostBean bean = new PostBean();
				bean.setTitle(title);
				bean.setId(id);
				bean.setContent(content);

				list.add(bean);
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public void addPost(PostBean postBean) {
		try {
			Connection con = dataFactory.getConnection();
			String title = postBean.getTitle();
			String id = postBean.getId();
			String content = postBean.getContent();
			String query = "insert into board";
			query += " (title, id, content)";
			query += " values(?,?,?)";
			System.out.println("prepareStatememt: " + query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, title);
			pstmt.setString(2, id);
			pstmt.setString(3, content);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void delPost(String title) {
		try {
			con = dataFactory.getConnection();
			String query = "delete from board" + " where title=?";
			System.out.println("prepareStatememt:" + query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, title);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void corPost(PostBean postBean) {
		try {
			Connection con = dataFactory.getConnection();
			String title = postBean.getTitle();
			String id = postBean.getId();
			String content = postBean.getContent();
			String query = "update board set";
			query += "content = ? where title = ?";
			System.out.println("prepareStatememt: " + query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, content);
			pstmt.setString(2, title);
			pstmt.executeUpdate();
			pstmt.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
}


